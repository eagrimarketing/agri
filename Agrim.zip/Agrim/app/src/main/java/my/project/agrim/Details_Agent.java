package my.project.agrim;

/**
 * Created by Vivek on 01-07-2017.
 */
public class Details_Agent {

    String Agent_ID, Agent_Name, Agent_Contact_Num, Agent_Address, Agent_Pickup_Village1, Agent_Pickup_Village2, Agent_Pickup_Village3, Agent_Pickup_Village4, Agent_Pickup_Village5, Agent_Pickup_Village6, Agent_Pickup_Village7, Agent_Pickup_Village8, Agent_Pickup_Village9, Agent_Pickup_Village10, Agent_Deliv_City1, Agent_Deliv_City2 = null;

    public Details_Agent(String agent_ID, String agent_Name, String agent_Contact_Num, String agent_Address, String agent_Pickup_Village1, String agent_Pickup_Village2, String agent_Pickup_Village3, String agent_Pickup_Village4, String agent_Pickup_Village5, String agent_Pickup_Village6, String agent_Pickup_Village7, String agent_Pickup_Village8, String agent_Pickup_Village9, String agent_Pickup_Village10, String agent_Deliv_City1, String agent_Deliv_City2) {
        Agent_ID = agent_ID;
        Agent_Name = agent_Name;
        Agent_Contact_Num = agent_Contact_Num;
        Agent_Address = agent_Address;
        Agent_Pickup_Village1 = agent_Pickup_Village1;
        Agent_Pickup_Village2 = agent_Pickup_Village2;
        Agent_Pickup_Village3 = agent_Pickup_Village3;
        Agent_Pickup_Village4 = agent_Pickup_Village4;
        Agent_Pickup_Village5 = agent_Pickup_Village5;
        Agent_Pickup_Village6 = agent_Pickup_Village6;
        Agent_Pickup_Village7 = agent_Pickup_Village7;
        Agent_Pickup_Village8 = agent_Pickup_Village8;
        Agent_Pickup_Village9 = agent_Pickup_Village9;
        Agent_Pickup_Village10 = agent_Pickup_Village10;
        Agent_Deliv_City1 = agent_Deliv_City1;
        Agent_Deliv_City2 = agent_Deliv_City2;
    }

    public String getAgent_ID() {
        return Agent_ID;
    }

    public void setAgent_ID(String agent_ID) {
        Agent_ID = agent_ID;
    }

    public String getAgent_Name() {
        return Agent_Name;
    }

    public void setAgent_Name(String agent_Name) {
        Agent_Name = agent_Name;
    }

    public String getAgent_Contact_Num() {
        return Agent_Contact_Num;
    }

    public void setAgent_Contact_Num(String agent_Contact_Num) {
        Agent_Contact_Num = agent_Contact_Num;
    }

    public String getAgent_Address() {
        return Agent_Address;
    }

    public void setAgent_Address(String agent_Address) {
        Agent_Address = agent_Address;
    }

    public String getAgent_Pickup_Village1() {
        return Agent_Pickup_Village1;
    }

    public void setAgent_Pickup_Village1(String agent_Pickup_Village1) {
        Agent_Pickup_Village1 = agent_Pickup_Village1;
    }

    public String getAgent_Pickup_Village2() {
        return Agent_Pickup_Village2;
    }

    public void setAgent_Pickup_Village2(String agent_Pickup_Village2) {
        Agent_Pickup_Village2 = agent_Pickup_Village2;
    }

    public String getAgent_Pickup_Village3() {
        return Agent_Pickup_Village3;
    }

    public void setAgent_Pickup_Village3(String agent_Pickup_Village3) {
        Agent_Pickup_Village3 = agent_Pickup_Village3;
    }

    public String getAgent_Pickup_Village4() {
        return Agent_Pickup_Village4;
    }

    public void setAgent_Pickup_Village4(String agent_Pickup_Village4) {
        Agent_Pickup_Village4 = agent_Pickup_Village4;
    }

    public String getAgent_Pickup_Village5() {
        return Agent_Pickup_Village5;
    }

    public void setAgent_Pickup_Village5(String agent_Pickup_Village5) {
        Agent_Pickup_Village5 = agent_Pickup_Village5;
    }

    public String getAgent_Pickup_Village6() {
        return Agent_Pickup_Village6;
    }

    public void setAgent_Pickup_Village6(String agent_Pickup_Village6) {
        Agent_Pickup_Village6 = agent_Pickup_Village6;
    }

    public String getAgent_Pickup_Village7() {
        return Agent_Pickup_Village7;
    }

    public void setAgent_Pickup_Village7(String agent_Pickup_Village7) {
        Agent_Pickup_Village7 = agent_Pickup_Village7;
    }

    public String getAgent_Pickup_Village8() {
        return Agent_Pickup_Village8;
    }

    public void setAgent_Pickup_Village8(String agent_Pickup_Village8) {
        Agent_Pickup_Village8 = agent_Pickup_Village8;
    }

    public String getAgent_Pickup_Village9() {
        return Agent_Pickup_Village9;
    }

    public void setAgent_Pickup_Village9(String agent_Pickup_Village9) {
        Agent_Pickup_Village9 = agent_Pickup_Village9;
    }

    public String getAgent_Pickup_Village10() {
        return Agent_Pickup_Village10;
    }

    public void setAgent_Pickup_Village10(String agent_Pickup_Village10) {
        Agent_Pickup_Village10 = agent_Pickup_Village10;
    }

    public String getAgent_Deliv_City1() {
        return Agent_Deliv_City1;
    }

    public void setAgent_Deliv_City1(String agent_Deliv_City1) {
        Agent_Deliv_City1 = agent_Deliv_City1;
    }

    public String getAgent_Deliv_City2() {
        return Agent_Deliv_City2;
    }

    public void setAgent_Deliv_City2(String agent_Deliv_City2) {
        Agent_Deliv_City2 = agent_Deliv_City2;
    }
}
