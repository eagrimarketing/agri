package my.project.agrim;

/**
 * Created by Vivek on 23-06-2017.
 */
public class Details_Shop {

    String DS_Shop_ID, DS_Buyer_ID, DS_Buyer_Name, DS_Buyer_Contact, DS_Plotnum, DS_Streetname, DS_City, DS_District, DS_State, DS_Latitude, DS_Longitude;

    public Details_Shop(String DS_Shop_ID, String DS_Buyer_ID, String DS_Buyer_Name, String DS_Buyer_Contact, String DS_Plotnum, String DS_Streetname, String DS_City, String DS_District, String DS_State, String DS_Latitude, String DS_Longitude) {
        this.DS_Shop_ID = DS_Shop_ID;
        this.DS_Buyer_ID = DS_Buyer_ID;
        this.DS_Buyer_Name = DS_Buyer_Name;
        this.DS_Buyer_Contact = DS_Buyer_Contact;
        this.DS_Plotnum = DS_Plotnum;
        this.DS_Streetname = DS_Streetname;
        this.DS_City = DS_City;
        this.DS_District = DS_District;
        this.DS_State = DS_State;
        this.DS_Latitude = DS_Latitude;
        this.DS_Longitude = DS_Longitude;
    }

    public String getDS_Shop_ID() {
        return DS_Shop_ID;
    }

    public void setDS_Shop_ID(String DS_Shop_ID) {
        this.DS_Shop_ID = DS_Shop_ID;
    }

    public String getDS_Buyer_ID() {
        return DS_Buyer_ID;
    }

    public void setDS_Buyer_ID(String DS_Buyer_ID) {
        this.DS_Buyer_ID = DS_Buyer_ID;
    }

    public String getDS_Buyer_Name() {
        return DS_Buyer_Name;
    }

    public void setDS_Buyer_Name(String DS_Buyer_Name) {
        this.DS_Buyer_Name = DS_Buyer_Name;
    }

    public String getDS_Buyer_Contact() {
        return DS_Buyer_Contact;
    }

    public void setDS_Buyer_Contact(String DS_Buyer_Contact) {
        this.DS_Buyer_Contact = DS_Buyer_Contact;
    }

    public String getDS_Plotnum() {
        return DS_Plotnum;
    }

    public void setDS_Plotnum(String DS_Plotnum) {
        this.DS_Plotnum = DS_Plotnum;
    }

    public String getDS_Streetname() {
        return DS_Streetname;
    }

    public void setDS_Streetname(String DS_Streetname) {
        this.DS_Streetname = DS_Streetname;
    }

    public String getDS_City() {
        return DS_City;
    }

    public void setDS_City(String DS_City) {
        this.DS_City = DS_City;
    }

    public String getDS_District() {
        return DS_District;
    }

    public void setDS_District(String DS_District) {
        this.DS_District = DS_District;
    }

    public String getDS_State() {
        return DS_State;
    }

    public void setDS_State(String DS_State) {
        this.DS_State = DS_State;
    }

    public String getDS_Latitude() {
        return DS_Latitude;
    }

    public void setDS_Latitude(String DS_Latitude) {
        this.DS_Latitude = DS_Latitude;
    }

    public String getDS_Longitude() {
        return DS_Longitude;
    }

    public void setDS_Longitude(String DS_Longitude) {
        this.DS_Longitude = DS_Longitude;
    }
}
