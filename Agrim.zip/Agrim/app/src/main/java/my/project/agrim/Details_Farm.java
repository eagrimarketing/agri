package my.project.agrim;

/**
 * Created by Vivek on 18-06-2017.
 */
public class Details_Farm {

    String DF_Farm_ID, DF_Farmer_ID, DF_Farmer_Name, DF_Farmer_Contact, DF_Plotnum, DF_Streetname, DF_Village, DF_District, DF_State,DF_Latitude, DF_Longitude;

    public Details_Farm(String Farm_ID, String Farmer_ID, String Farmer_Name, String Farmer_Contact, String Plotnum, String Streetname, String Village, String District, String State, String Latitude, String Longitude) {
        this.DF_Farm_ID = Farm_ID;
        this.DF_Farmer_ID = Farmer_ID;
        this.DF_Farmer_Name = Farmer_Name;
        this.DF_Farmer_Contact = Farmer_Contact;
        this.DF_Plotnum = Plotnum;
        this.DF_Streetname = Streetname;
        this.DF_Village = Village;
        this.DF_District = District;
        this.DF_State = State;
        this.DF_Latitude = Latitude;
        this.DF_Longitude = Longitude;
    }


    public String getDF_Farm_ID() {
        return DF_Farm_ID;
    }

    public void setDF_Farm_ID(String DF_Farm_ID) {
        this.DF_Farm_ID = DF_Farm_ID;
    }

    public String getDF_Farmer_ID() {
        return DF_Farmer_ID;
    }

    public void setDF_Farmer_ID(String DF_Farmer_ID) {
        this.DF_Farmer_ID = DF_Farmer_ID;
    }

    public String getDF_Farmer_Name() {
        return DF_Farmer_Name;
    }

    public void setDF_Farmer_Name(String DF_Farmer_Name) {
        this.DF_Farmer_Name = DF_Farmer_Name;
    }

    public String getDF_Farmer_Contact() {
        return DF_Farmer_Contact;
    }

    public void setDF_Farmer_Contact(String DF_Farmer_Contact) {
        this.DF_Farmer_Contact = DF_Farmer_Contact;
    }

    public String getDF_Plotnum() {
        return DF_Plotnum;
    }

    public void setDF_Plotnum(String DF_Plotnum) {
        this.DF_Plotnum = DF_Plotnum;
    }

    public String getDF_Streetname() {
        return DF_Streetname;
    }

    public void setDF_Streetname(String DF_Streetname) {
        this.DF_Streetname = DF_Streetname;
    }

    public String getDF_Village() {
        return DF_Village;
    }

    public void setDF_Village(String DF_Village) {
        this.DF_Village = DF_Village;
    }

    public String getDF_District() {
        return DF_District;
    }

    public void setDF_District(String DF_District) {
        this.DF_District = DF_District;
    }

    public String getDF_State() {
        return DF_State;
    }

    public void setDF_State(String DF_State) {
        this.DF_State = DF_State;
    }

    public String getDF_Latitude() {
        return DF_Latitude;
    }

    public void setDF_Latitude(String DF_Latitude) {
        this.DF_Latitude = DF_Latitude;
    }

    public String getDF_Longitude() {
        return DF_Longitude;
    }

    public void setDF_Longitude(String DF_Longitude) {
        this.DF_Longitude = DF_Longitude;
    }
}
